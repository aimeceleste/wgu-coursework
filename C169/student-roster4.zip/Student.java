
/**
 * A student has an ID, first and last names, an email address, an age, and an array of grades.
 *
 * @author celestet@
 * @version 1.0
 */
public class Student { 
	private String studentID = "";
	private String firstName = "";
	private String lastName = "";
	private String emailAddress = "";
	private int age = 0;
	private int[] grades = new int[3];
	
		// constructor		
		public Student(String studentID, String firstName, String lastName, String emailAddress, int age, int[] grades){
			setStudentID(studentID);
			setFirstName(firstName);
			setLastName(lastName);
			setEmailAddress(emailAddress);
			setAge(age);
			setGrades(grades);
		}
		
		/* getter for each variable*/
		public String getStudentID(){
			return this.studentID;
		}
		public String getFirstName(){
			return this.firstName;
		}
		public String getLastName(){
			return this.lastName;
		}
		public String getEmailAddress(){
			return this.emailAddress;
		}
		public int getAge(){
			return this.age;
		}
		public int[] getGrades(){
			return this.grades;
		}
		
		/* setter for each variable */
		public void setStudentID(String studentID){
			this.studentID = studentID;
		}
		public void setFirstName(String firstName){
			this.firstName = firstName;
		}
			
		public void setLastName(String lastName){
			this.lastName = lastName;
		}
		
		public void setEmailAddress(String emailAddress){
			this.emailAddress = emailAddress;
		}
		
		public void setAge(int age){
			this.age = age;
		}

		public void setGrades(int[] grades){
			this.grades = grades;
		}
		
		//Print method
		public void print(){
			System.out.println(
					"Student ID:\t" + getStudentID() +
					"\tFirst Name:\t" + getFirstName() +
					"\tLast Name:\t" + getLastName() +
					"\tEmail Address:\t" + getEmailAddress() + 
					"\tAge:\t" + getAge());
		}	
	}
